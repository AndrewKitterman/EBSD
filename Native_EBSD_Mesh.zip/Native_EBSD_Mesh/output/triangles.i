[Mesh]
 [file]
  type = FileMeshGenerator
  file = triangles/grains.msh
 []
[]
