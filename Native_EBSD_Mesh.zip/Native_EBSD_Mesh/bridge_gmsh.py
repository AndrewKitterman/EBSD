"""Mesh a labeled grain partition using one shared planar boundary network.

Geometry is the exact raster-cell union. Collinear vertices are removed only at
degree-two graph nodes. No smoothing or removal of grains/particles is applied.
"""

from pathlib import Path
import argparse, json, time
from collections import defaultdict
import numpy as np
from shapely.geometry import LineString
from shapely.geometry.polygon import orient
from shapely.ops import polygonize
import gmsh
import meshio


def network(labels):
    ny, nx = labels.shape
    edges = []
    for j in range(ny + 1):
        for i in range(nx):
            if j == 0 or j == ny or labels[j - 1, i] != labels[j, i]:
                edges.append(((i, j), (i + 1, j)))
    for i in range(nx + 1):
        for j in range(ny):
            if i == 0 or i == nx or labels[j, i - 1] != labels[j, i]:
                edges.append(((i, j), (i, j + 1)))
    deg = defaultdict(int)
    for a, b in edges:
        deg[a] += 1
        deg[b] += 1
    polys = list(polygonize([LineString(e) for e in edges]))
    return edges, deg, polys


def mesh_case(case, h_pixels=2.0, name="conformal"):
    case = Path(case)
    a = np.load(case)
    labels = a["FeatureIds"]
    phase = a["Phases"]
    eu = a["EulerAngles"]
    dx, dy = a["spacing"]
    xorigin, yorigin = a["origin"]
    if labels.ndim != 2 or phase.shape != labels.shape or eu.shape != labels.shape + (3,):
        raise ValueError("Expected grain/phase arrays (ny,nx), Euler angles (ny,nx,3).")
    ny, nx = labels.shape
    if not np.issubdtype(labels.dtype, np.integer) or not np.issubdtype(phase.dtype, np.integer):
        raise ValueError("Grain and phase arrays must use integer dtypes.")
    if np.any(phase < 0) or not all(np.isfinite(v).all() for v in [eu, a["spacing"], a["origin"]]):
        raise ValueError("Nonnegative phases and finite geometry/orientation values required.")
    if min(dx, dy, h_pixels) <= 0 or not np.isfinite(h_pixels) or np.any(labels < 0):
        raise ValueError("Spacing and mesh size must be positive; grain IDs must be nonnegative.")
    for grain in np.unique(labels):
        if np.unique(phase[labels == grain]).size != 1:
            raise ValueError(
                "Each grain ID must belong to one phase. Split phase-crossing grains first."
            )
    t = time.perf_counter()
    edges, deg, polys = network(labels)
    gmsh.initialize()
    gmsh.option.setNumber("General.Terminal", 0)
    gmsh.model.add(str(name))
    points = {}
    lines = {}
    surfaces = defaultdict(list)
    face_labels = {}

    def point(xy):
        q = tuple(map(int, xy))
        if q not in points:
            points[q] = gmsh.model.geo.addPoint(
                xorigin + q[0] * dx, yorigin + q[1] * dy, 0, h_pixels * min(dx, dy)
            )
        return points[q]

    def curve(a, b):
        a, b = tuple(a), tuple(b)
        key = tuple(sorted((a, b)))
        if key not in lines:
            lines[key] = gmsh.model.geo.addLine(point(key[0]), point(key[1]))
        return lines[key] if (a, b) == key else -lines[key]

    def ring(coords):
        p = [tuple(map(int, q[:2])) for q in list(coords)[:-1]]
        keep = []
        for i, q in enumerate(p):
            before = p[i - 1]
            after = p[(i + 1) % len(p)]
            cross = (q[0] - before[0]) * (after[1] - q[1]) - (q[1] - before[1]) * (after[0] - q[0])
            # Preserve junctions; remove only straight degree-two vertices.
            if deg[q] != 2 or cross != 0:
                keep.append(q)
        return gmsh.model.geo.addCurveLoop([curve(u, v) for u, v in zip(keep, keep[1:] + keep[:1])])

    # Build each interface once. Neighboring surfaces reuse its curve tag.
    for poly in polys:
        poly = orient(poly, sign=1.0)
        pt = poly.representative_point()
        ix = min(nx - 1, int(pt.x))
        iy = min(ny - 1, int(pt.y))
        g = int(labels[iy, ix])
        loops = [ring(poly.exterior.coords)] + [ring(r.coords) for r in poly.interiors]
        tag = gmsh.model.geo.addPlaneSurface(loops)
        surfaces[g].append(tag)
        face_labels[tag] = g
    gmsh.model.geo.synchronize()
    for g, s in surfaces.items():
        tag = gmsh.model.addPhysicalGroup(2, s, g + 1)
        gmsh.model.setPhysicalName(2, tag, f"grain_{g}")
    # Domain boundary groups and all material/grain interfaces are retained.
    boundary = defaultdict(list)
    for (u, v), tag in lines.items():
        if u[0] == v[0] == 0:
            boundary["left"].append(tag)
        elif u[0] == v[0] == nx:
            boundary["right"].append(tag)
        elif u[1] == v[1] == 0:
            boundary["bottom"].append(tag)
        elif u[1] == v[1] == ny:
            boundary["top"].append(tag)
        else:
            boundary["internal_interfaces"].append(tag)
    for idx, (name_, tags) in enumerate(boundary.items(), 1):
        if tags:
            gmsh.model.addPhysicalGroup(1, tags, idx)
            gmsh.model.setPhysicalName(1, idx, name_)
    gmsh.option.setNumber("Mesh.Algorithm", 6)
    gmsh.option.setNumber("Mesh.MeshSizeMin", min(dx, dy) * min(h_pixels, 0.25))
    gmsh.option.setNumber("Mesh.MeshSizeMax", min(dx, dy) * h_pixels)
    gmsh.option.setNumber("Mesh.MshFileVersion", 2.2)
    gmsh.model.mesh.generate(2)
    out = Path(name)
    out.mkdir(parents=True, exist_ok=True)
    gmsh.write(str(out / "grains.msh"))
    nt, xyz, _ = gmsh.model.mesh.getNodes()
    xyz = np.asarray(xyz).reshape(-1, 3)
    node_index = {int(n): i for i, n in enumerate(nt)}
    triangles = []
    gids = []
    for face, g in face_labels.items():
        types, etags, enodes = gmsh.model.mesh.getElements(2, face)
        for typ, conn in zip(types, enodes):
            if typ != 2:
                raise RuntimeError(f"Unexpected element type {typ}")
            tri = np.asarray(
                [[node_index[int(k)] for k in row] for row in np.asarray(conn).reshape(-1, 3)]
            )
            triangles.append(tri)
            gids.extend([g] * len(tri))
    tri = np.vstack(triangles)
    gids = np.asarray(gids, dtype=np.int32)
    cent = xyz[tri].mean(axis=1)
    ix = np.clip(((cent[:, 0] - xorigin) / dx).astype(int), 0, nx - 1)
    iy = np.clip(((cent[:, 1] - yorigin) / dy).astype(int), 0, ny - 1)
    ep = phase[iy, ix]
    ee = eu[iy, ix]
    cross = np.cross(xyz[tri[:, 1]] - xyz[tri[:, 0]], xyz[tri[:, 2]] - xyz[tri[:, 0]])[:, 2]
    if np.any(cross <= 0):
        raise RuntimeError("Non-positive element orientation")
    area = cross / 2
    ref = np.bincount(labels.ravel(), minlength=labels.max() + 1) * dx * dy
    actual = np.bincount(gids, weights=area, minlength=len(ref))
    counts = defaultdict(list)
    for elem, trow in enumerate(tri):
        for u, v in [(trow[0], trow[1]), (trow[1], trow[2]), (trow[2], trow[0])]:
            counts[tuple(sorted((int(u), int(v))))].append(elem)
    adjacency = set()
    outer_length = 0.0
    bad_edges = 0
    for (u, v), els in counts.items():
        if len(els) == 2:
            g1, g2 = gids[els]
            if g1 != g2:
                adjacency.add(tuple(sorted((int(g1), int(g2)))))
        elif len(els) == 1:
            mid = (xyz[u] + xyz[v]) / 2
            if not (
                np.isclose(mid[0], xorigin)
                or np.isclose(mid[0], xorigin + nx * dx)
                or np.isclose(mid[1], yorigin)
                or np.isclose(mid[1], yorigin + ny * dy)
            ):
                bad_edges += 1
            outer_length += float(np.linalg.norm(xyz[u] - xyz[v]))
        else:
            bad_edges += 1
    refadj = set()
    for q, r in [(labels[:, :-1], labels[:, 1:]), (labels[:-1], labels[1:])]:
        refadj.update(tuple(sorted(map(int, k))) for k in np.column_stack([q[q != r], r[q != r]]))
    lengths = np.stack(
        [
            np.linalg.norm(xyz[tri[:, i]] - xyz[tri[:, j]], axis=1)
            for i, j in [(0, 1), (1, 2), (2, 0)]
        ],
        axis=1,
    )
    quality = 4 * np.sqrt(3) * area / (lengths**2).sum(axis=1)
    # Euler angles are sampled from the source pixel at the element centroid.
    # The mesh fits grain/phase boundaries, but can span orientation gradients.
    data = {
        "grain_id": [gids],
        "phase_id": [ep],
        "phi1_rad": [ee[:, 0]],
        "Phi_rad": [ee[:, 1]],
        "phi2_rad": [ee[:, 2]],
    }
    meshio.write(out / "grains.vtu", meshio.Mesh(xyz, [("triangle", tri)], cell_data=data))
    # Gmsh physical IDs start at 1: block_id = grain_id + 1, including unknown 0.
    table = np.array([(int(g) + 1, int(g), int(phase[labels == g][0])) for g in np.unique(gids)])
    np.savetxt(
        out / "grain_phase_blocks.csv",
        table,
        fmt="%d",
        delimiter=",",
        header="block_id,grain_id,phase_id",
        comments="",
    )
    np.savez_compressed(
        out / "mesh_arrays.npz", points=xyz, triangles=tri, grain_id=gids, phase_id=ep, euler_rad=ee
    )
    summary = {
        "nodes": len(xyz),
        "triangles": len(tri),
        "geometric_faces": len(polys),
        "h_pixels": h_pixels,
        "total_area_um2": float(area.sum()),
        "max_grain_area_error_um2": float(np.max(abs(ref - actual))),
        "phase_area_um2": {str(p): float(area[ep == p].sum()) for p in np.unique(ep)},
        "min_triangle_quality": float(quality.min()),
        "min_signed_twice_area": float(cross.min()),
        "label_mismatches": int(np.sum(labels[iy, ix] != gids)),
        "unpaired_internal_or_nonmanifold_edges": bad_edges,
        "adjacency_symmetric_difference": len(adjacency ^ refadj),
        "boundary_length_error_um": abs(outer_length - 2 * (nx * dx + ny * dy)),
        "seconds": time.perf_counter() - t,
        "geometry": "Exact labeled raster; collinear degree-two points removed; no smoothing.",
    }
    assert summary["label_mismatches"] == 0 and bad_edges == 0 and adjacency == refadj
    assert np.allclose(ref, actual, rtol=1e-9, atol=1e-9)
    (out / "mesh_validation.json").write_text(json.dumps(summary, indent=2))
    gmsh.finalize()
    print(json.dumps(summary, indent=2))
    return summary


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("case")
    ap.add_argument("--h-pixels", type=float, default=2.0)
    ap.add_argument("--name", default="output")
    a = ap.parse_args()
    mesh_case(a.case, a.h_pixels, a.name)
