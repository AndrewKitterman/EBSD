[Mesh]
  [ebsd]
    type = EBSDMeshGenerator
    filename = 'microstructure.inl'
  []
[]
[UserObjects]
  [reader]
    type = EBSDReader
  []
[]
[AuxVariables]
  [phase]
    family = MONOMIAL
    order = CONSTANT
  []
  [grain]
    family = MONOMIAL
    order = CONSTANT
  []
  [phi1]
    family = MONOMIAL
    order = CONSTANT
  []
  [Phi]
    family = MONOMIAL
    order = CONSTANT
  []
  [phi2]
    family = MONOMIAL
    order = CONSTANT
  []
  [symmetry]
    family = MONOMIAL
    order = CONSTANT
  []
[]
[AuxKernels]
  [phase]
    type = EBSDReaderPointDataAux
    variable = phase
    data_name = phase
    ebsd_reader = reader
    execute_on = initial
  []
  [grain]
    type = EBSDReaderPointDataAux
    variable = grain
    data_name = feature_id
    ebsd_reader = reader
    execute_on = initial
  []
  [phi1]
    type = EBSDReaderPointDataAux
    variable = phi1
    data_name = phi1
    ebsd_reader = reader
    execute_on = initial
  []
  [Phi]
    type = EBSDReaderPointDataAux
    variable = Phi
    data_name = phi
    ebsd_reader = reader
    execute_on = initial
  []
  [phi2]
    type = EBSDReaderPointDataAux
    variable = phi2
    data_name = phi2
    ebsd_reader = reader
    execute_on = initial
  []
  [symmetry]
    type = EBSDReaderPointDataAux
    variable = symmetry
    data_name = symmetry
    ebsd_reader = reader
    execute_on = initial
  []
[]
[Problem]
  solve = false
  kernel_coverage_check = false
[]
[Postprocessors]
  [elements]
    type = NumElements
  []
  [nodes]
    type = NumNodes
  []
[]
[Executioner]
  type = Steady
[]
[Outputs]
  exodus = true
  csv = true
  execute_on = 'initial final'
[]
