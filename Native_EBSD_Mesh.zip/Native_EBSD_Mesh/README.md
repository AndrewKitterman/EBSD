# Native EBSD software driver

This package calls **simplnx / OrientationAnalysis**, **MOOSE**, and optionally **Gmsh**. Grain reconstruction runs through the official compiled simplnx filters. The Python code orchestrates the software and transfers data. There is no independent Python grain-segmentation implementation.

## What each program does

| Task | Software |
| --- | --- |
| Read Oxford CTF | `orientationanalysis.ReadCtfDataFilter` |
| Euler angles to quaternions | `orientationanalysis.ConvertOrientationsFilter` |
| Identify indexed pixels | `simplnx.MultiThresholdObjectsFilter` |
| Segment orientation features | `orientationanalysis.EBSDSegmentFeaturesFilter` |
| Compute feature phases and counts | Native simplnx filters |
| Export INL EBSD data | `orientationanalysis.WriteINLFileFilter` |
| Create a pixel-aligned quadrilateral mesh | MOOSE `EBSDMeshGenerator` |
| Read grain, phase, and orientation fields | MOOSE `EBSDReader` / `EBSDReaderPointDataAux` |
| Assign grain subdomains | MOOSE `SubdomainPerElementGenerator` |
| Generate optional conforming triangles | Gmsh |
| Import the triangular mesh into MOOSE | MOOSE `FileMeshGenerator` |

**Default route:** simplnx → INL → MOOSE quadrilateral mesh. This route uses native segmentation and native mesh construction.

**Optional triangular route:** simplnx → grain boundary adapter → Gmsh → MOOSE. The adapter (`bridge_gmsh.py`) constructs the shared raster boundary network with Shapely and calls Gmsh's mesher. It is custom geometry-transfer code. Gmsh does not read a CTF grain map on its own. This route retains the adapter used for our prior triangular meshes; it does not replace Gmsh's meshing algorithm.

## 1. Install the software

The tested platform is Linux x86-64. On Windows, use a Linux environment such as WSL2 for this MOOSE workflow. WSL2 and macOS execution have not been tested here.

Use Miniforge/Conda or micromamba. Keep the simplnx Python environment separate from the MOOSE environment to avoid Python/dependency conflicts.

```bash
conda create -n ebsd-native -c bluequartzsoftware -c conda-forge python=3.12 dream3dnx=26.08.28 pip
conda activate ebsd-native
python -m pip install -r requirements-gmsh.txt
```

`dream3dnx` is the vendor's distribution containing the `simplnx` and `orientationanalysis` Python modules. This driver uses those open-source modules without opening the commercial GUI. Installing the distribution also installs GUI components; a paid GUI license is not needed for these Python filter calls. The vendor's installation page documents this distribution, and its developer has stated that the simplnx component has no timeout. See Sources below.

For the quadrilateral route alone, `requirements.txt` supplies the Python bookkeeping dependencies. `requirements-gmsh.txt` adds the optional triangular meshing dependencies. On Ubuntu/Debian, install `libglu1-mesa` if Gmsh reports a missing `libGLU.so.1`.

Install the tested MOOSE binary in a separate environment:

```bash
conda create -n moose-ebsd -c https://conda.software.inl.gov/public -c conda-forge moose=2026.10.30=mpich
conda run -n moose-ebsd python -c "import sys; from pathlib import Path; print(Path(sys.prefix)/'bin'/'moose-opt')"
```

Copy the printed absolute executable path for the next step. A MOOSE application built from source must include the `phase_field` module to provide the EBSD objects. A bare framework-only application is insufficient. MOOSE's official installation instructions are linked below. The example binary installation is the configuration used in our tests, not a requirement for every MOOSE application.

## 2. Run the Python script

Activate `ebsd-native`, then open a terminal in this package folder:

```bash
python run.py --moose /absolute/path/to/moose-opt
```

This reads `data/synthetic_dp_carbides.ctf` and creates `output/grains.e`, a native MOOSE quadrilateral mesh with grain subdomains.

To also create triangles and import them into MOOSE:

```bash
python run.py --moose /absolute/path/to/moose-opt --gmsh
```

For the measured martensitic crop:

```bash
python run.py --moose /absolute/path/to/moose-opt --input data/API-5_roi.ctf --output output_measured --gmsh
```

For the smaller ferrite/martensite-only fixture:

```bash
python run.py --moose /absolute/path/to/moose-opt --input data/dual_phase.ctf --output output_dual_phase --gmsh
```

Use another rectangular 2D CTF file with `--input`. The pipeline is configured for CTF; ANG and other formats require their native reader filter and corresponding array paths. No generic PNG/JPEG reader is included.

`--angle 5` is the default grain misorientation threshold. Native software warnings/errors are retained in `simplnx_log.json` and MOOSE logs. An unsuccessful subprocess or a failed transfer check stops the driver. Run Python without `-O` so verification assertions remain enabled.

## 3. Notebook driver

`driver.ipynb` calls the same script. Install Jupyter support in `ebsd-native` if needed:

```bash
python -m pip install ipykernel matplotlib
python -m ipykernel install --user --name ebsd-native --display-name "EBSD native software"
```

Open the notebook in VS Code or Jupyter, choose that kernel, set `MOOSE_EXE` in its configuration cell, and run the cells. The notebook displays grain/phase maps and mesh figures. The default notebook runs the measured crop and the full synthetic carbide fixture. Neither native executable is bundled in the ZIP.

## 4. Code layout

- `nx_pipeline.py`: native simplnx filter calls and INL header-convention transfer.
- `run.py`: orchestration, native MOOSE inputs, block assignment, and checks.
- `templates/reader.i`: readable MOOSE input for mesh generation and field import.
- `bridge_gmsh.py`: optional shared-boundary geometry adapter and calls to Gmsh, with geometric checks.
- `driver.ipynb`: notebook configuration, execution, and visualization.
- `data/`: included CTF examples and measured-data provenance.

There is no `segment.py` in this package. Do not mix these scripts with the preceding `Simple_EBSD_Mesh` package.

## 5. Coordinate and label conventions

The original native NX INL export is preserved as `native.inl`. For this pinned NX version, the MOOSE-compatible copy `microstructure.inl` sets `Z_DIM=0` and shifts X/Y bounds by minus half a scan step. This makes each EBSD point a pixel center in the 2D MOOSE mesh. Data rows, orientations, phases, and grain IDs remain unchanged.

This header adjustment is specific to the tested NX exporter. DREAM3D 6.5 uses a different convention; do not apply the NX adjustment to its output.

The native MOOSE quadrilateral mesh uses `block_id = grain_id`. The Gmsh file uses `block_id = grain_id + 1` because physical tags must be positive. Both routes write their own `grain_phase_blocks.csv`; use the table next to the mesh you import. Unknown grain ID zero remains present in the NX output and requires a material-model decision.

## 6. Outputs and materials

| Output | Meaning |
| --- | --- |
| `native.inl` | Unchanged native simplnx export |
| `microstructure.inl` | Header-adapted input for MOOSE |
| `pipeline.d3dpipeline` | Serialized native simplnx pipeline |
| `reader_out.e` | MOOSE quadrilateral mesh with imported grain, phase, Euler-angle, and symmetry fields |
| `grains.e` | MOOSE mesh partitioned into grain subdomains |
| `grain_phase_blocks.csv` | Native MOOSE grain-block/phase map |
| `native_arrays.npz` | Native exported data in array form for transfer/inspection |
| `triangles/grains.msh` | Optional Gmsh mesh with grain and boundary physical groups |
| `triangles/grains.vtu` | Optional triangle mesh with phase/grain/orientation cell fields |
| `triangles.e` | Optional triangular mesh after native MOOSE import |
| `verification.json` | Mesh counts and transfer checks |

`grains.e` and `triangles.e` are mesh-only outputs. The grain/phase mapping tells a mechanical solver which constitutive law belongs on each block. The script does not calibrate properties or solve loading. `reader_out.e` carries imported field data; the mesh-only files do not contain a mechanics solution.

The full synthetic fixture uses phase 1=ferrite surrogate, phase 2=martensite surrogate, phase 3=carbide surrogate. The smaller dual-phase fixture uses phases 1 and 2. The measured crop uses 0=unindexed, 1=BCC indexing, 2=FCC indexing. BCC indexing alone does not identify ferrite versus martensite.

## 7. Verification and limits

Executed with native simplnx from `dream3dnx=26.08.28`, Gmsh 4.15.2, and MOOSE 2026.10.30 (MPICH):

| Input | MOOSE quads | Grain blocks | Gmsh nodes | Gmsh triangles |
| --- | ---: | ---: | ---: | ---: |
| Measured martensitic crop | 12,288 | 106 (105 indexed + unknown 0) | 12,302 | 24,328 |
| Full synthetic carbide fixture | 12,288 | 54 | 10,051 | 19,871 |
| Smaller ferrite/martensite fixture | 3,072 | 48 | 2,603 | 5,086 |

All three native pipelines and MOOSE imports passed. Both original pictured grain partitions matched the saved NX references up to grain-ID relabeling, and their triangle/node counts matched. The measured scan retained all 607 unindexed pixels. Native source-phase checks and MOOSE grain/phase transfer checks had zero mismatches. The Gmsh meshes had zero adjacency differences or unpaired internal/nonmanifold edges. See `regression_results.json` and the per-case `verification.json` files.

The notebook's four code cells executed in sequence through IPython in the NX environment, including both native pipelines and figure creation. A separate Jupyter kernel could not be launched because this execution environment blocks kernel sockets. Notebook schema validation passed. The notebook contains saved outputs; set your own MOOSE path before rerunning.

The headless vendor module printed a missing GUI preferences-file message in this environment; its filters completed without errors. Use filter results and subprocess exit codes to distinguish fatal failures from this startup message.


The driver checks source CTF phase labels against the native INL export, then checks MOOSE's imported phase/grain fields against that export. It checks the element and block counts of the final native MOOSE mesh. The Gmsh adapter checks signed area, per-grain area, centroid labels, shared-edge conformity, and grain adjacency. The final triangle count is checked after MOOSE import.

The examples are capability and transfer tests. They do not validate a measured dual-phase constituent classification, material parameters, or mechanics mesh convergence. The source pixel partition limits geometric accuracy. Raster stair steps remain; the code does not smooth boundaries or reconstruct prior austenite. Small carbides below scan resolution cannot be recovered.

The native simplnx filter supports crystal symmetries represented by its reader and crystallographic implementation; this wrapper does not impose the former custom segmenter's cubic-only check. Only the included cubic-indexed examples have been tested here. Use native phase metadata appropriate to the material, and validate new symmetry classes before use.

The measured crop is martensitic steel. The two other inputs are synthetic. A threshold-defined orientation feature is not a guaranteed physical grain, martensite packet, or prior-austenite grain.

### Why this package uses simplnx instead of legacy 6.5

A native 6.5 test on the measured crop showed that its `ReadCtfData` implementation replaces phase values below 1 with phase 1. The source contains this conversion in `ReadCtfData.cpp`. This changed the unknown regions and grain partition. We did not patch the segmentation or silently repair the resulting phases. The package uses the current native simplnx reader and an indexed-pixel mask instead.

Legacy 6.5 worked on the two fully indexed synthetic fixtures, but its output mesh counts differed from NX because of coordinate conventions and meshing details. Those legacy trial outputs are not the outputs shipped as successful NX results.

## 8. Software and data sources

- simplnx Python installation: https://www.dream3d.io/python_docs/Installation.html
- Python filter usage: https://www.dream3d.io/python_docs/Python_Introduction.html
- simplnx source (AGPLv3; inspect the pinned release's license): https://github.com/BlueQuartzSoftware/simplnx
- Vendor explanation of Python use without a GUI license: https://groups.google.com/g/dream3d-users/c/hvAfWpukCBw
- Vendor explanation of script/filter use: https://groups.google.com/g/dream3d-users/c/y4KKyWDoIxY
- MOOSE EBSD generator: https://mooseframework.inl.gov/source/meshgenerators/EBSDMeshGenerator.html
- MOOSE installation: https://mooseframework.inl.gov/getting_started/installation/
- Gmsh (GPL with stated exceptions): https://gmsh.info/
- Shapely (BSD): https://github.com/shapely/shapely
- meshio (MIT): https://github.com/nschloe/meshio

The measured data are a CC0 crop of API-5.ctf from Breumier et al., *EBSD Maps acquired on different steels with transformed microstructures*, https://doi.org/10.12763/RHWHD7 . File DOI: https://doi.org/10.57745/ARJ6IA . `data/API-5_roi.json` records the crop indices and source-coordinate translation. Synthetic files are controlled fixtures from our preceding tests. Software dependencies retain their own licenses. No vendor software binaries are redistributed here.
