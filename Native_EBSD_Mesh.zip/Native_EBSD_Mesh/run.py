"""Call native simplnx and MOOSE; optional Gmsh triangular-mesh export."""

import argparse
import json
import io
import os
import subprocess
from pathlib import Path
import numpy as np
from netCDF4 import Dataset, chartostring

ROOT = Path(__file__).resolve().parent


def execute(command, folder, log, env):
    """Keep native program output and stop if a program reports failure."""
    with (folder / log).open("w") as stream:
        subprocess.run(
            [str(x) for x in command],
            cwd=folder,
            env=env,
            stdout=stream,
            stderr=subprocess.STDOUT,
            check=True,
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--moose", required=True, type=Path, help="MOOSE with phase_field module")
    parser.add_argument("--input", type=Path, default=ROOT / "data/synthetic_dp_carbides.ctf")
    parser.add_argument("--output", type=Path, default=ROOT / "output")
    parser.add_argument("--angle", type=float, default=5.0)
    parser.add_argument("--gmsh", action="store_true", help="Also mesh grain polygons with Gmsh")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.setdefault("UCX_TLS", "self")  # Serial execution; supports restricted local environments.
    env.setdefault("OMP_NUM_THREADS", "1")
    from nx_pipeline import export_ctf

    export_ctf(args.input, out, args.angle)
    # Validation only: check native phase export against the raw CTF labels.
    ctf_lines = args.input.read_text().splitlines()
    first = next(i for i, line in enumerate(ctf_lines) if line.startswith("Phase\tX\tY"))
    source = np.loadtxt(io.StringIO("\n".join(ctf_lines[first + 1 :])), usecols=(0, 1, 2))
    # Read native output for bookkeeping only. simplnx computed all grain IDs.
    text = (out / "microstructure.inl").read_text()
    header = dict(
        line[2:].split(":", 1)
        for line in text.splitlines()
        if line.startswith("# ") and ":" in line
    )
    if int(header["Z_DIM"]) != 0:
        raise ValueError("This template expects a 2D INL export (Z_DIM=0).")
    data = np.loadtxt(out / "microstructure.inl", comments="#")
    nx, ny = int(header["X_DIM"]), int(header["Y_DIM"])
    dx, dy = float(header["X_STEP"]), float(header["Y_STEP"])
    origin = np.array([float(header["X_MIN"]), float(header["Y_MIN"])])
    ix, iy = np.floor((data[:, 3:5] - origin) / [dx, dy]).astype(int).T
    if len(data) != nx * ny or not np.array_equal(np.sort(iy * nx + ix), np.arange(nx * ny)):
        raise ValueError("INL coordinates do not form the expected complete rectangular grid.")
    grain = np.zeros((ny, nx), dtype=int)
    phase = grain.copy()
    euler = np.zeros((ny, nx, 3))
    grain[iy, ix], phase[iy, ix], euler[iy, ix] = (
        data[:, 6].astype(int),
        data[:, 7].astype(int),
        data[:, :3],
    )
    source_order = np.lexsort((source[:, 1], source[:, 2]))
    assert np.array_equal(
        phase.ravel(), source[source_order, 0].astype(int)
    ), "Native phase transfer changed the input."
    np.savez_compressed(
        out / "native_arrays.npz",
        FeatureIds=grain,
        Phases=phase,
        EulerAngles=euler,
        spacing=[dx, dy],
        origin=origin,
    )
    # MOOSE creates the grid and reads the INL grain/phase/orientation fields.
    reader = (ROOT / "templates/reader.i").read_text()
    (out / "reader.i").write_text(reader)
    execute([args.moose.resolve(), "-i", "reader.i"], out, "moose_reader.log", env)
    with Dataset(out / "reader_out.e") as mesh:
        coordinates = np.column_stack([mesh["coordx"][:], mesh["coordy"][:]])
        connectivity = np.asarray(mesh["connect1"][:]) - 1
        centers = coordinates[connectivity].mean(axis=1)
        names = list(chartostring(mesh["name_elem_var"][:]))
        fields = {
            name: np.asarray(mesh[f"vals_elem_var{i+1}eb1"][-1]) for i, name in enumerate(names)
        }
        ids = np.asarray(mesh["elem_num_map"][:]) - 1
        # Use MOOSE's imported grain field to request native grain subdomains.
        tags = np.rint(fields["grain"]).astype(int)
        ci, cj = np.floor((centers - origin) / [dx, dy]).astype(int).T
        assert np.array_equal(tags, grain[cj, ci])
        assert np.array_equal(np.rint(fields["phase"]).astype(int), phase[cj, ci])
        summary = dict(
            nodes=len(coordinates),
            quadrilaterals=len(connectivity),
            grain_blocks=len(np.unique(tags)),
            grain_label_errors=0,
            phase_label_errors=0,
            source_phase_errors=0,
        )
    block_generator = f"""  [grains]
    type = SubdomainPerElementGenerator
    input = ebsd
    element_ids = '{' '.join(map(str,ids))}'
    subdomain_ids = '{' '.join(map(str,tags))}'
  []
"""
    # Insert the native block-assignment generator before the end of [Mesh].
    split = reader.index("[UserObjects]")
    mesh_text = reader[:split].rstrip()
    mesh_text = mesh_text[:-2] + block_generator + "[]\n"
    (out / "grains.i").write_text(mesh_text)
    execute(
        [args.moose.resolve(), "-i", "grains.i", "--mesh-only", "grains.e"],
        out,
        "moose_blocks.log",
        env,
    )
    with Dataset(out / "grains.e") as mesh:
        assert len(mesh.dimensions["num_elem"]) == nx * ny
        assert set(map(int, mesh["eb_prop1"][:])) == set(map(int, np.unique(grain)))
    # One constitutive law can be assigned to all blocks of a given phase.
    rows = []
    for g in np.unique(grain):
        phases = np.unique(phase[grain == g])
        if len(phases) != 1:
            raise ValueError("A native grain spans more than one phase.")
        rows.append((int(g), int(phases[0])))
    np.savetxt(
        out / "grain_phase_blocks.csv",
        rows,
        fmt="%d",
        delimiter=",",
        header="block_id,phase_id",
        comments="",
    )
    if args.gmsh:
        # This adapter describes the raster boundaries; Gmsh generates the triangles.
        from bridge_gmsh import mesh_case

        summary["gmsh"] = mesh_case(out / "native_arrays.npz", name=out / "triangles")
        (out / "triangles.i").write_text(
            "[Mesh]\n [file]\n  type = FileMeshGenerator\n  file = triangles/grains.msh\n []\n[]\n"
        )
        execute(
            [args.moose.resolve(), "-i", "triangles.i", "--mesh-only", "triangles.e"],
            out,
            "moose_triangles.log",
            env,
        )
        with Dataset(out / "triangles.e") as mesh:
            assert len(mesh.dimensions["num_elem"]) == summary["gmsh"]["triangles"]
            assert set(map(int, mesh["eb_prop1"][:])) == {int(g) + 1 for g in np.unique(grain)}
        summary["gmsh"]["moose_import"] = "passed"
    summary["source"] = "Native simplnx filters; no Python grain segmentation"
    (out / "verification.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
