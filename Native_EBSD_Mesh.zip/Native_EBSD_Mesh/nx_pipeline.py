"""Native simplnx EBSD filters, called through the official Python bindings."""

from pathlib import Path
import json
import simplnx as nx
import orientationanalysis as ox


def export_ctf(source, out, angle=5.0):
    out = Path(out)
    ds = nx.DataStructure()
    pipeline = nx.Pipeline()
    events = []
    p = nx.DataPath

    def execute(filter_type, **parameters):
        result = filter_type.execute(data_structure=ds, **parameters)
        events.append(
            {
                "filter": filter_type.__name__,
                "errors": [str(e) for e in result.errors],
                "warnings": [str(w) for w in result.warnings],
            }
        )
        (out / "simplnx_log.json").write_text(json.dumps(events, indent=2))
        if result.errors:
            raise RuntimeError(events[-1])
        pipeline.append(filter_type(), parameters)

    execute(
        ox.ReadCtfDataFilter,
        input_file=Path(source).resolve(),
        output_image_geometry_path=p("EBSD"),
        degrees_to_radians=True,
        edax_hexagonal_alignment=False,
    )
    execute(
        ox.ConvertOrientationsFilter,
        input_orientation_array_path=p("EBSD/Cell Data/EulerAngles"),
        input_representation_index=0,
        output_representation_index=2,
        output_orientation_array_name="Quats",
    )
    # Native threshold filter excludes unindexed pixels from grain segmentation.
    threshold = nx.ArrayThreshold()
    threshold.array_path = p("EBSD/Cell Data/Phases")
    threshold.comparison = nx.ArrayThreshold.ComparisonType.GreaterThan
    threshold.value = 0
    thresholds = nx.ArrayThresholdSet()
    thresholds.thresholds = [threshold]
    execute(
        nx.MultiThresholdObjectsFilter,
        array_thresholds_object=thresholds,
        output_data_array_name="Indexed",
        created_mask_type=nx.DataType.boolean,
    )
    execute(
        ox.EBSDSegmentFeaturesFilter,
        input_image_geometry_path=p("EBSD"),
        cell_phases_array_path=p("EBSD/Cell Data/Phases"),
        cell_quats_array_path=p("EBSD/Cell Data/Quats"),
        crystal_structures_array_path=p("EBSD/Cell Ensemble Data/CrystalStructures"),
        cell_mask_array_path=p("EBSD/Cell Data/Indexed"),
        use_mask=True,
        misorientation_tolerance=angle,
        randomize_features=False,
        is_periodic=False,
    )
    execute(
        nx.ComputeFeaturePhasesFilter,
        cell_features_attribute_matrix_path=p("EBSD/Cell Feature Data"),
        cell_phases_array_path=p("EBSD/Cell Data/Phases"),
        feature_ids_path=p("EBSD/Cell Data/FeatureIds"),
    )
    execute(
        nx.ComputeNumFeaturesFilter,
        ensemble_attribute_matrix_path=p("EBSD/Cell Ensemble Data"),
        feature_phases_array_path=p("EBSD/Cell Feature Data/Phases"),
    )
    execute(
        ox.WriteINLFileFilter,
        input_image_geometry_path=p("EBSD"),
        output_file=out / "native.inl",
        cell_euler_angles_array_path=p("EBSD/Cell Data/EulerAngles"),
        cell_phases_array_path=p("EBSD/Cell Data/Phases"),
        crystal_structures_array_path=p("EBSD/Cell Ensemble Data/CrystalStructures"),
        feature_ids_array_path=p("EBSD/Cell Data/FeatureIds"),
        material_name_array_path=p("EBSD/Cell Ensemble Data/MaterialName"),
        num_features_array_path=p("EBSD/Cell Ensemble Data/Number of Features"),
    )
    pipeline.to_file(out / "pipeline.d3dpipeline")
    # Format convention bridge: NX writes a one-slice 3D header and corner bounds.
    # MOOSE's 2D reader needs Z_DIM=0 and bounds enclosing the sample centers.
    text = (out / "native.inl").read_text()
    header = dict(
        line[2:].split(":", 1)
        for line in text.splitlines()
        if line.startswith("# ") and ":" in line
    )
    lines = []
    for line in text.splitlines():
        if line.startswith("# Z_DIM:"):
            line = "# Z_DIM: 0"
        for axis in ["X", "Y"]:
            for bound in ["MIN", "MAX"]:
                key = f"{axis}_{bound}"
                if line.startswith(f"# {key}:"):
                    line = f'# {key}: {float(header[key])-0.5*float(header[axis+"_STEP"]):.9f}'
        lines.append(line)
    (out / "microstructure.inl").write_text("\n".join(lines) + "\n")
